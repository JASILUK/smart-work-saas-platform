from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError
from apps.companies.models import Company, Membership
from apps.attendance.models.daily_attendance import DailyAttendance
from apps.attendance.models.attendance_event import AttendanceEvent, AttendanceMethodChoices
from apps.attendance.services.daily_attendance_engine import DailyAttendanceEngine

class HRAttendanceManagementService:
    """
    Handles corporate timesheet modifications, reprocessing, 
    and payroll finalizations safely within explicit transaction parameters.
    """

    @classmethod
    @transaction.atomic
    def inject_manual_correction_event(
        cls, *, company: Company, admin_actor: Membership, data: dict
    ) -> AttendanceEvent:
        target_member = Membership.objects.filter(id=data["membership_id"], company=company).first()
        if not target_member:
            raise ValidationError("Target employee membership profile missing.")

        target_date = data["attendance_date"]
        sheet = DailyAttendance.objects.filter(company=company, membership=target_member, attendance_date=target_date).first()
        if sheet and sheet.finalized_at:
            raise ValidationError("Modifications blocked: This attendance sheet is finalized for payroll.")

        event = AttendanceEvent.objects.create(
            company=company,
            membership=target_member,
            event_type=data["event_type"],
            attendance_method=AttendanceMethodChoices.MANUAL,
            event_time=data["event_time"],
            notes=data["reason"],
            created_by=admin_actor,
            is_system_generated=False,
            verification_payload={"executed_by_admin_id": admin_actor.id}
        )

        DailyAttendanceEngine.build_daily_attendance(company=company, membership=target_member, target_date=target_date)
        return event

    @classmethod
    @transaction.atomic
    def finalize_record(cls, *, company: Company, admin_actor: Membership, record_id: int) -> DailyAttendance:
        record = DailyAttendance.objects.filter(id=record_id, company=company).first()
        if not record:
            raise ValidationError("Daily attendance record not traced.")
        if record.needs_review:
            raise ValidationError("Cannot finalize a record with outstanding unresolved HR review flags.")

        record.finalized_at = timezone.now()
        record.finalized_by = admin_actor
        record.save(update_fields=["finalized_at", "finalized_by", "updated_at"])
        return record

    @classmethod
    @transaction.atomic
    def unlock_record(cls, *, company: Company, record_id: int) -> DailyAttendance:
        record = DailyAttendance.objects.filter(id=record_id, company=company).first()
        if not record:
            raise ValidationError("Daily attendance record not traced.")

        record.finalized_at = None
        record.finalized_by = None
        record.save(update_fields=["finalized_at", "finalized_by", "updated_at"])
        return record

    @classmethod
    @transaction.atomic
    def reprocess_record_timeline(cls, *, company: Company, record_id: int) -> DailyAttendance:
        record = DailyAttendance.objects.filter(id=record_id, company=company).first()
        if not record:
            raise ValidationError("Daily attendance record not traced.")

        return DailyAttendanceEngine.build_daily_attendance(
            company=company, membership=record.membership, target_date=record.attendance_date
        )