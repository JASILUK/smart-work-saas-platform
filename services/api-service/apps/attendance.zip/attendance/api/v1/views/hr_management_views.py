from rest_framework import status
from rest_framework.response import Response
from django.utils import timezone
from apps.companies.api.base import BaseCompanyAPIView
from apps.core.api_response import ApiResponse
from apps.core.standers_pagination import StandardLimitOffsetPagination

from apps.attendance.selectors.hr_management_selector import HRAttendanceManagementSelector
from apps.attendance.selectors.attendance_event_selector import AttendanceEventSelector
from apps.attendance.services.hr_management_service import HRAttendanceManagementService
from apps.attendance.api.v1.serializers.hr_serializers import (
    HRDashboardSummaryResponseSerializer, AdminManualCorrectionSerializer, CorporateDailyAttendanceListSerializer
)
from apps.attendance.api.v1.serializers.daily_attendance_serializers import (
    DailyAttendanceDetailSerializer, AttendanceTimelineSerializer
)
from apps.attendance.models.daily_attendance import DailyAttendance

class HRAttendanceDashboardSummaryAPI(BaseCompanyAPIView):
    required_permissions = {"GET": "tenant.attendance.manage"}

    def get(self, request, *args, **kwargs) -> Response:
        target_date_str = request.query_params.get("date")
        target_date = timezone.datetime.strptime(target_date_str, "%Y-%m-%d").date() if target_date_str else timezone.localdate()

        analytics = HRAttendanceManagementSelector.get_aggregated_dashboard_summary(company=request.company, target_date=target_date)
        serializer = HRDashboardSummaryResponseSerializer(analytics)
        return ApiResponse.success(data=serializer.data)


class HRCompanyRecordsLedgerAPI(BaseCompanyAPIView):
    required_permissions = {"GET": "tenant.attendance.manage"}

    def get(self, request, *args, **kwargs) -> Response:
        date_from = request.query_params.get("date_from")
        date_to = request.query_params.get("date_to")
        status_filter = request.query_params.get("status")
        membership_id = request.query_params.get("membership")
        department_id = request.query_params.get("department")
        search_query = request.query_params.get("search")

        parsed_from = timezone.datetime.strptime(date_from, "%Y-%m-%d").date() if date_from else None
        parsed_to = timezone.datetime.strptime(date_to, "%Y-%m-%d").date() if date_to else None

        records = HRAttendanceManagementSelector.list_daily_attendance_ledger(
            company=request.company, date_from=parsed_from, date_to=parsed_to, status=status_filter,
            membership_id=int(membership_id) if membership_id else None,
            department_id=int(department_id) if department_id else None, search_query=search_query
        )

        paginator = StandardLimitOffsetPagination()
        page = paginator.paginate_queryset(records, request)
        serializer = CorporateDailyAttendanceListSerializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)


class HRCorrectionOverrideAPI(BaseCompanyAPIView):
    required_permissions = {"POST": "tenant.attendance.manage"}

    def post(self, request, *args, **kwargs) -> Response:
        serializer = AdminManualCorrectionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        event = HRAttendanceManagementService.inject_manual_correction_event(
            company=request.company, admin_actor=request.membership, data=serializer.validated_data
        )
        return ApiResponse.success(data={"event_id": event.id, "status": "SYNCHRONIZATION_COMPLETED"})


class HRRecordDetailActionsAPI(BaseCompanyAPIView):
    required_permissions = {"GET": "tenant.attendance.manage", "POST": "tenant.attendance.manage"}

    def get(self, request, pk: int, *args, **kwargs) -> Response:
        record = DailyAttendance.objects.filter(id=pk, company=request.company).first()
        if not record:
            return ApiResponse.not_found("Attendance record sheet not found.")

        events = AttendanceEventSelector.get_events_for_membership_and_date(membership=record.membership, date=record.attendance_date)
        return ApiResponse.success(data={
            "daily_record": DailyAttendanceDetailSerializer(record).data,
            "timeline": AttendanceTimelineSerializer(events, many=True).data
        })

    def post(self, request, pk: int, *args, **kwargs) -> Response:
        action_type = request.data.get("action")
        
        if action_type == "finalize":
            record = HRAttendanceManagementService.finalize_record(company=request.company, admin_actor=request.membership, record_id=pk)
        elif action_type == "unlock":
            record = HRAttendanceManagementService.unlock_record(company=request.company, record_id=pk)
        elif action_type == "reprocess":
            record = HRAttendanceManagementService.reprocess_record_timeline(company=request.company, record_id=pk)
        else:
            return ApiResponse.error(message="Invalid action request parameter attribute.", status=status.HTTP_400_BAD_REQUEST)
            
        return ApiResponse.success(data=DailyAttendanceDetailSerializer(record).data, message=f"Action '{action_type}' successfully applied.")