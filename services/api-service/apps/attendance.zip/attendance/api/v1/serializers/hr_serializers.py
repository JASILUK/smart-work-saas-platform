from rest_framework import serializers
from apps.attendance.models.daily_attendance import DailyAttendance
from apps.attendance.models.attendance_event import AttendanceEvent

class HRDashboardStatisticsSerializer(serializers.Serializer):
    present = serializers.IntegerField()
    absent = serializers.IntegerField()
    half_day = serializers.IntegerField()
    late = serializers.IntegerField()
    leave = serializers.IntegerField()
    holiday = serializers.IntegerField()
    weekend = serializers.IntegerField()
    review_required = serializers.IntegerField()

class HRDepartmentBreakdownSerializer(serializers.Serializer):
    department_name = serializers.CharField()
    present_count = serializers.IntegerField()
    absent_count = serializers.IntegerField()
    late_count = serializers.IntegerField()

class HRDashboardSummaryResponseSerializer(serializers.Serializer):
    statistics = HRDashboardStatisticsSerializer()
    department_breakdown = HRDepartmentBreakdownSerializer(many=True)

class CorporateDailyAttendanceListSerializer(serializers.ModelSerializer):
    employee_id = serializers.IntegerField(source="membership.id", read_only=True)
    employee_name = serializers.CharField(source="membership.user.username", read_only=True)
    department_name = serializers.CharField(source="membership.department.name", read_only=True, default="N/A")
    job_title = serializers.CharField(source="membership.job_title", read_only=True, default="Staff")
    is_finalized = serializers.SerializerMethodField()

    class Meta:
        model = DailyAttendance
        fields = [
            "id", "employee_id", "employee_name", "department_name", "job_title",
            "attendance_date", "attendance_status", "first_check_in_at", "last_check_out_at",
            "total_work_minutes", "total_break_minutes", "late_minutes", "early_exit_minutes",
            "overtime_minutes", "needs_review", "is_finalized", "created_at"
        ]

    def get_is_finalized(self, obj) -> bool:
        return obj.finalized_at is not None

class AdminManualCorrectionSerializer(serializers.Serializer):
    membership_id = serializers.IntegerField(required=True)
    attendance_date = serializers.DateField(required=True)
    event_type = serializers.ChoiceField(choices=["CHECK_IN", "CHECK_OUT", "BREAK_OUT", "BREAK_IN"], required=True)
    event_time = serializers.DateTimeField(required=True)
    reason = serializers.CharField(required=True, min_length=10)